# ENCAR_CHROME_EXTENSION_SPEC.md

이 파일은 이전 대화에서 정리된 기준 명세서를 프로젝트 내부에서 참조하기 위한 placeholder 이다.

실제 기준 내용은 사용자 제공 명세 문서를 프로젝트에 복사해 넣거나,
현재 대화에서 작성된 'ENCAR Chrome Extension 가격 추적기 명세서'를 그대로 반영하면 된다.

핵심 기준:
- Encar 방문 기반 수집
- LIST/DETAIL 대상
- carId 우선 식별
- chrome.storage.local 저장
- ACTIVE/MISSING/SUSPECT_SOLD/ARCHIVED 상태 관리
- 상세 오버레이
- popup 최근 목록
- 중복 실행 방지
- SPA 대응
- 외부 전송 금지
