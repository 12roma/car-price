# STORAGE_POLICY.md

## 저장소 목표
Phase 1에서는 `chrome.storage.local` 만 사용한다.
그러나 향후 Supabase로 이관이 쉽도록 repository 추상화 관점을 유지한다.

---

## 저장 단위
차량 단위 문서를 저장한다.

기본 키:
- `carId`
- 없으면 fallback key

---

## upsert 원칙
1. 기존 차량 조회
2. 대표 필드 병합
3. history append 여부 계산
4. status/lastSeenAt 반영
5. 다시 저장

---

## 병합 규칙
- DETAIL 정보가 LIST 정보보다 우선
- title/url은 더 신뢰도 높은 값을 유지
- source.fromList / source.fromDetail 은 한번 true 되면 유지
- firstSeenAt 은 최초값 유지
- lastSeenAt 은 최신값 반영

---

## history 원칙
- 최초 발견 시 1건 추가
- 가격 변경 시 추가
- 같은 날 같은 가격은 추가 금지
- 옵션으로 하루 1건 허용 정책은 feature flag화 가능

---

## 조회 원칙
popup/recent 조회 시점에 status를 재평가할 수 있게 설계한다.

즉,
- 저장 시점 상태 반영
- 조회 시점 장기 미확인 재평가
둘 다 가능해야 한다.
