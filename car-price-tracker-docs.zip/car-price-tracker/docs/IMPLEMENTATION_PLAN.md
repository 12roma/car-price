# IMPLEMENTATION_PLAN.md

## 목표
한 번에 전부 구현하지 않고, 단계별로 안전하게 구현한다.

---

## Phase 0. 문서/골격 준비
### 목표
- 프로젝트 구조 확정
- 요구사항 및 정책 문서 정리
- 하네스 전략 정의

### 산출물
- `CLAUDE.md`
- `docs/ARCHITECTURE.md`
- `docs/HARNESS.md`
- `docs/TEST_PLAN.md`

### 완료 기준
- 구현자가 무엇을 만들어야 하는지 문서만 읽고 이해 가능

---

## Phase 1. Extension 골격
### 목표
- Manifest V3 기본 구조
- popup/content/background 최소 연결

### 산출물
- `manifest.json`
- `background.js`
- `content.js`
- `popup.html`
- `popup.js`
- `styles.css`

### 완료 기준
- 확장 프로그램이 chrome://extensions 에서 로드됨
- Encar 페이지에서 content script 주입 확인 가능

---

## Phase 2. 공통 유틸/도메인 모델
### 목표
- 상수, enum, time/price normalize 준비
- vehicle/history 기본 모델 규약 확정

### 산출물
- `utils/constants.js`
- `utils/price.js`
- `utils/merge.js`

### 완료 기준
- 가격 normalize, diff 계산, append policy 테스트 가능

---

## Phase 3. Extractor 구현
### 목표
- LIST/DETAIL 추출기 작성
- fixture 기반 회귀 가능하게 작성

### 산출물
- `utils/extractor.js`
- `fixtures/list/*.html`
- `fixtures/detail/*.html`
- `expected/*.json`
- `harness/extractor.harness.js`

### 완료 기준
- fixture 기준 기대값과 실제 추출값이 일치

---

## Phase 4. Storage/Status 구현
### 목표
- local repository
- upsert/merge
- status transition

### 산출물
- `utils/storage.js`
- `utils/status.js`
- `harness/status.harness.js`
- `harness/history.harness.js`

### 완료 기준
- 중복 저장 방지
- ACTIVE/MISSING/SUSPECT_SOLD/ARCHIVED 검증 통과

---

## Phase 5. Content Orchestrator
### 목표
- 현재 페이지 판별
- SPA navigation 감지
- debounce/retry
- LIST/DETAIL 처리 흐름 연결

### 산출물
- `content.js`
- `utils/pageDetector.js`
- `harness/replay.harness.js`

### 완료 기준
- 동일 페이지 중복 저장 방지
- URL 변경 시 정상 재동작

---

## Phase 6. Overlay UI
### 목표
- 상세 페이지 가격 비교 UI 주입
- 중복 렌더 방지

### 산출물
- `utils/overlay.js`
- `styles.css`
- `harness/ui.harness.js`

### 완료 기준
- 오버레이 1개만 존재
- 이전가/현재가/변동폭 표시

---

## Phase 7. Popup UI
### 목표
- 최근 차량 목록
- 최신 가격/변동/상태 표시

### 산출물
- `popup.html`
- `popup.js`

### 완료 기준
- 최근 확인순 정렬
- 클릭 시 차량 페이지 이동 가능

---

## Phase 8. 안정화
### 목표
- selector fallback 보강
- fixture 추가
- 예외 처리 보강
- README 정리

### 완료 기준
- 대표 시나리오 기준 회귀 테스트 세트 확보
