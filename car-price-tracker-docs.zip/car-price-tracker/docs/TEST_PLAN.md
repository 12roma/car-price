# TEST_PLAN.md

## 1. 우선 테스트 범위
### A. Extractor
- LIST 기본 추출
- LIST 복수 카드 추출
- DETAIL 기본 추출
- carId fallback
- price 누락 처리

### B. Domain Policy
- price normalize
- history dedup
- price diff 계산
- merge 우선순위
- status transition

### C. UI
- overlay 생성
- overlay 재실행 시 중복 방지
- popup 최근 정렬

### D. Flow
- LIST 처리
- DETAIL 처리
- SPA URL 변경 처리
- debounce/retry 처리

---

## 2. 대표 시나리오
### 시나리오 1
LIST 페이지 처음 방문
- 여러 차량 저장
- 모두 ACTIVE
- history 1건 생성

### 시나리오 2
같은 LIST 다시 열기
- 같은 날 같은 가격이면 history 추가 없음

### 시나리오 3
DETAIL 진입
- fromDetail=true
- lastSeenAt 갱신
- overlay 렌더

### 시나리오 4
가격 하락
- 새 history 추가
- popup diff 음수 반영

### 시나리오 5
추출 실패 반복
- MISSING 증가
- 3회 이상이면 SUSPECT_SOLD

### 시나리오 6
장기 미확인
- 30일 이상이면 ARCHIVED

---

## 3. 수동 점검 체크리스트
- 확장 로드 성공
- Encar 외 페이지에서 동작 안 함
- overlay가 상세 페이지에서만 뜸
- popup 클릭 시 원본 차량 페이지로 이동
- storage local 데이터 구조가 명세와 일치
- 중복 observer로 과도 저장 안 됨

---

## 4. 회귀 방지 우선순위
가장 먼저 깨지기 쉬운 순서대로 관리한다.

1. extractor selector
2. history dedup
3. SPA 중복 실행
4. overlay 중복 렌더
5. popup 정렬
