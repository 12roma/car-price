# PHASE1_TASKS.md

## 바로 실행할 작업 순서

### Task 1. 프로젝트 초기 골격 생성
- manifest.json
- background.js
- content.js
- popup.html
- popup.js
- styles.css
- utils/ 디렉터리 생성

### Task 2. 공통 상수/모델 정의
- 상태값 enum
- source 타입
- history record 형태
- overlay DOM id 상수

### Task 3. extractor 초안 작성
- isListPage()
- isDetailPage()
- extractListVehicles()
- extractDetailVehicle()
- getCarIdFromUrl()

### Task 4. price/history 정책 구현
- normalizePrice()
- shouldAppendHistory()
- getLatestPrice()
- getPreviousPrice()
- getPriceDiff()

### Task 5. storage 구현
- getVehicle()
- getAllVehicles()
- upsertVehicle()
- getRecentVehicles()

### Task 6. status 구현
- markActive()
- markMissing()
- deriveStatusByTime()

### Task 7. content orchestrator 연결
- page detect
- debounce
- retry
- list/detail 분기
- save/update call

### Task 8. overlay UI
- render/update
- diff 표시
- first tracked 표시

### Task 9. popup UI
- 최근 차량 목록
- 최신 가격/변동/상태
- 클릭 시 이동

### Task 10. harness 최소 세트 작성
- extractor fixture harness
- history harness
- status harness
- overlay harness
